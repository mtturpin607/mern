package com.example.userscrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserscrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
