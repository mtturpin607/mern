package com.example.userscrud.service;

import com.example.userscrud.entity.Post;

public interface PostService {
	
	Post createPost(Post post);

}
